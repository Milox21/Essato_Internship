﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientApp.Helpers
{
    public class ClearMessenger<T>
    {
        public T Message { get; set; }
    }
}
