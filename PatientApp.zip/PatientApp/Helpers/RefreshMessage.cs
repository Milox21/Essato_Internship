﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientApp.Helpers
{
    public class RefreshMessage<T>
    {
        public T Message { get; set; }
    }
}
